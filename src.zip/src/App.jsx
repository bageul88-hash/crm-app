import { Routes, Route, Navigate } from 'react-router-dom'
import { useEffect } from 'react'
import { useApp } from './context/AppContext'

import ListPage from './pages/ListPage'
import InputPage from './pages/InputPage'
import SchedulePage from './pages/SchedulePage'
import SMSPage from './pages/SMSPage'
import DetailPage from './pages/DetailPage'
import AttendancePage from './pages/AttendancePage'
import LoginPage from './pages/LoginPage'

import CallBanner from './components/CallBanner'
import BottomNav from './components/BottomNav'

export default function App() {
  const { load, currentUser, logout } = useApp()

  useEffect(() => {
    if (currentUser) load()
  }, [load, currentUser])

  if (!currentUser) return <LoginPage />

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="brand-wrap">
          <div className="brand-logo">C</div>
          <div className="brand-title">
            <strong>상담</strong>
            <strong>CRM</strong>
          </div>
        </div>

        <div className="user-box">
          <strong>{currentUser?.branchName || currentUser?.name || '본사'}</strong>
          <span>{currentUser?.role === 'admin' ? '관리자' : currentUser?.name}</span>
        </div>

        <div className="header-actions">
          <button type="button" className="header-btn" onClick={logout}>로그아웃</button>
          <button type="button" className="refresh-btn" onClick={load} title="새로고침">↻</button>
        </div>
      </header>

      <main className="app-main">
        <Routes>
          <Route path="/" element={<ListPage />} />
          <Route path="/input" element={<InputPage />} />
          <Route path="/input/:id" element={<InputPage />} />
          <Route path="/schedule" element={<SchedulePage />} />
          <Route path="/sms" element={<SMSPage />} />
          <Route path="/detail/:id" element={<DetailPage />} />
          <Route path="/attendance" element={<AttendancePage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

      <CallBanner />
      <BottomNav />
    </div>
  )
}
