import { useLocation, useNavigate } from 'react-router-dom'

const NAV = [
  { path: '/', icon: '≡', label: '상담목록' },
  { path: '/input', icon: '+', label: '상담등록' },
  { path: '/schedule', icon: '◷', label: '예약일' },
  { path: '/sms', icon: '✉', label: '문자대상' },
  { path: '/attendance', icon: '✔', label: '출석관리' },
]

export default function BottomNav() {
  const navigate = useNavigate()
  const location = useLocation()

  const isActive = path => {
    if (path === '/') return location.pathname === '/'
    if (path === '/input') return location.pathname.startsWith('/input')
    return location.pathname.startsWith(path)
  }

  return (
    <nav className="bottom-nav">
      {NAV.map(item => {
        const active = isActive(item.path)

        return (
          <button
            key={item.path}
            type="button"
            className={`bottom-nav-btn ${active ? 'active' : ''}`}
            onClick={() => navigate(item.path)}
          >
            <span className="bottom-nav-icon">{item.icon}</span>
            <span className="bottom-nav-label">{item.label}</span>
          </button>
        )
      })}
    </nav>
  )
}
