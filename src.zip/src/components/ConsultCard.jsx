function fmtDate(value) {
  if (!value) return ''
  const str = String(value)
  const match = str.match(/^(\d{4})-(\d{2})-(\d{2})/)
  return match ? `${match[1]}-${match[2]}-${match[3]}` : str.slice(0, 10)
}


const DAY_KR = ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일']

function getDayFromDate(value) {
  const dateStr = fmtDate(value)
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return ''

  const [y, m, d] = dateStr.split('-').map(Number)
  const date = new Date(y, m - 1, d)

  if (
    date.getFullYear() !== y ||
    date.getMonth() !== m - 1 ||
    date.getDate() !== d
  ) {
    return ''
  }

  return DAY_KR[date.getDay()]
}

function formatAge(value) {
  if (!value) return ''
  const text = String(value).trim()
  return text.endsWith('세') ? text : `${text}세`
}

function getStatus(consult) {
  if (consult.diagResult) return consult.diagResult
  if (consult.category) return consult.category
  return ''
}

function hasLessonSchedule(consult) {
  return Boolean(consult.lessonDate || consult.lessonDay || consult.lessonTime)
}

function canShowLesson(consult) {
  const status = getStatus(consult)

  return (
    hasLessonSchedule(consult) &&
    (status === '예약' || status === '등록' || status === '수업중')
  )
}

function getLessonText(consult) {
  if (!canShowLesson(consult)) return ''

  const date = fmtDate(consult.lessonDate)
  const day = consult.lessonDay || getDayFromDate(consult.lessonDate) || ''
  const time = consult.lessonTime || ''
  const parts = [date, day, time].filter(Boolean)

  return parts.length ? `수업중 - ${parts.join(' ')}` : ''
}

export default function ConsultCard({ consult, onClick, onEdit, onDelete }) {
  const c = consult || {}
  const status = getStatus(c)
  const lessonText = getLessonText(c)
  const phone = c.phone || '-'

  return (
    <article className="consult-card fade-in" onClick={onClick}>
      <div className="consult-card-top">
        <div className="consult-info">
          <h3>{c.name || '(이름없음)'}</h3>
          <p>
            {phone}
            {c.age ? ` · ${formatAge(c.age)}` : ''}
          </p>
          <p>
            {c.gender || ''}
            {c.relation ? ` · ${c.relation}` : ''}
          </p>
        </div>

        <div className="card-actions">
          <button
            type="button"
            className="mini-btn edit"
            onClick={e => {
              e.stopPropagation()
              onEdit?.()
            }}
          >
            수정
          </button>
          <button
            type="button"
            className="mini-btn delete"
            onClick={e => {
              e.stopPropagation()
              onDelete?.()
            }}
          >
            삭제
          </button>
        </div>
      </div>

      {c.feature && <p className="consult-feature">{c.feature}</p>}

      <div className="consult-dates">
        {c.inquiryDate && <span>📅 {fmtDate(c.inquiryDate)}</span>}
        {c.diagDate && (
          <span>🔔 {fmtDate(c.diagDate)}{c.diagTime ? ` ${c.diagTime}` : ''}</span>
        )}
      </div>

      <div className="consult-bottom">
        <div className="consult-bottom-left">
          {status && <span className="status-chip">{status}</span>}
          {lessonText && <span className="lesson-chip">{lessonText}</span>}
        </div>
      </div>
    </article>
  )
}
