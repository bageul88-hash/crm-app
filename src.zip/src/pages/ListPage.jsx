import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import ConsultCard from '../components/ConsultCard'

function hasLessonSchedule(c) {
  return Boolean(
    c?.lessonDate ||
    c?.lessonDay ||
    c?.lessonTime ||
    c?.lessonReserveDate ||
    c?.lessonReserveDay ||
    c?.lessonReserveTime
  )
}

const TABS = [
  { key: '전체', label: '전체', match: () => true },
  { key: '예약', label: '예약', match: c => c.category === '예약' && !c.diagResult },
  { key: '문의', label: '문의', match: c => c.category === '문의' },
  {
    key: '수업중',
    label: '수업중',
    match: c =>
      c.category === '수업중' ||
      c.diagResult === '수업중' ||
      (c.diagResult === '등록' && hasLessonSchedule(c)),
  },
  { key: '핑크', label: '핑크', match: c => c.category === '핑크' || c.diagResult === '핑크' },
  { key: '등록', label: '등록', match: c => c.diagResult === '등록' && !hasLessonSchedule(c) },
  { key: '미등록', label: '미등록', match: c => c.diagResult === '미등록' },
  { key: '연결', label: '연결', match: c => c.category === '연결' || c.diagResult === '연결' },
  { key: '환불', label: '환불', match: c => c.category === '환불' || c.diagResult === '환불' },
]

function searchText(c) {
  return [c.name, c.phone, c.feature, c.relation, c.category, c.diagResult]
    .filter(Boolean)
    .join(' ')
    .toLowerCase()
}

export default function ListPage() {
  const { consults, loading, error, remove } = useApp()
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState('전체')
  const [search, setSearch] = useState('')

  const counts = useMemo(() => {
    return TABS.reduce((acc, tab) => {
      acc[tab.key] = consults.filter(tab.match).length
      return acc
    }, {})
  }, [consults])

  const filtered = useMemo(() => {
    const tab = TABS.find(t => t.key === activeTab) || TABS[0]
    const q = search.trim().toLowerCase()

    return consults
      .filter(tab.match)
      .filter(c => !q || searchText(c).includes(q))
      .sort((a, b) => Number(b.id || 0) - Number(a.id || 0))
  }, [consults, activeTab, search])

  const handleDelete = async id => {
    if (!window.confirm('정말 삭제하시겠습니까?')) return
    try {
      await remove(id)
    } catch (e) {
      alert(`삭제 중 오류가 발생했습니다.\n${e.message || e}`)
    }
  }

  const openRegister = phone => {
    const query = phone ? `?phone=${encodeURIComponent(phone)}` : ''
    navigate(`/input${query}`)
  }

  return (
    <section className="list-page">
      <div className="search-box">
        <span>🔍</span>
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="이름, 전화번호, 특징 검색"
        />
      </div>

      <div className="tab-wrap">
        {TABS.map(tab => {
          const active = activeTab === tab.key
          return (
            <button
              key={tab.key}
              type="button"
              className={`category-chip ${active ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.key)}
            >
              {tab.label} <span>{counts[tab.key] || 0}</span>
            </button>
          )
        })}
      </div>

      <div className="list-divider" />

      <div className="consult-list">
        {loading && (
          <div className="center-box"><div className="spinner" /></div>
        )}

        {error && <div className="error-box">⚠️ {error}</div>}

        {!loading && !error && filtered.length === 0 && (
          <div className="empty-box">📋<br />상담 내역이 없습니다</div>
        )}

        {!loading && !error && filtered.map(c => (
          <ConsultCard
            key={c.id}
            consult={c}
            onClick={() => navigate(`/detail/${c.id}`)}
            onEdit={() => navigate(`/input/${c.id}`)}
            onDelete={() => handleDelete(c.id)}
            onRegister={openRegister}
          />
        ))}
      </div>
    </section>
  )
}
