import { useState } from 'react'
import { useApp } from '../context/AppContext'

export default function LoginPage() {
  const { login } = useApp()

  const [id, setId] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  const handleLogin = () => {
    try {
      login(id, password)
      window.location.reload()
    } catch (e) {
      setError(e.message)
    }
  }

  return (
    <div style={{ padding: 20 }}>
      <h2>CRM 로그인</h2>

      <input
        placeholder="아이디"
        value={id}
        onChange={e => setId(e.target.value)}
        style={{ display: 'block', marginBottom: 10 }}
      />

      <input
        type="password"
        placeholder="비밀번호"
        value={password}
        onChange={e => setPassword(e.target.value)}
        style={{ display: 'block', marginBottom: 10 }}
      />

      <button onClick={handleLogin}>로그인</button>

      {error && (
        <p style={{ color: 'red', marginTop: 10 }}>
          {error}
        </p>
      )}
    </div>
  )
}